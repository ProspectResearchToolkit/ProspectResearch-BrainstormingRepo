# Prospect Dev Software List

| Name | $ Service | Software category | Use-cases |
|------|-----------|-------------------|-----------|
| DonorSearch | Paid |  | Past giving research |
| iWave/Kindsight | Paid |  | Past giving research |
| LexisNexis | Paid |  | Past giving research |
| ResearchPoint | Paid |  | Past giving research |
| RelSci | Paid |  | Past giving research |
